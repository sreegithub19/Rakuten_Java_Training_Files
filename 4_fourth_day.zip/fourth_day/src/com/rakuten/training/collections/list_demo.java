package com.rakuten.training.collections;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class list_demo {
	public static void main(String[] args) {
	//	demoAutoBoxing();
	//	demoRawType();
		
	//	demo_specific_list();
		List<String> strList = new ArrayList<String>();
		my_algo(strList);
	}
	
	//my_algo is now not coupled to linked_list or array_list
	//here, it is loose coupling
	//this is the idea behind programming to interface
	//all lists are index-based (array_list, linked_list etc.)
	private static void my_algo(List<String> strList) {
		strList.add("abc");
		strList.add(0,"first");
		String s = strList.get(1);
		//......
		System.out.println("Type of list is:"+ strList.getClass().getName());
		
/* fourth day commented
		for(int i=0;i<strList.size();i++) {
			String an_element = strList.get(i);  //get() is random access 
			// here, we are using a random access method to implementing sequential traversal
			//so, get() is efficient for array_list, but very inefficient for linked_list
			// to avoid this, we use an object called iterator. It helps us to
			//efficiently iterate/loop over any collection
			System.out.println(an_element);
		}
		
		//itertor can be used to iterate efficiently over 
		//indexable(list) and non-indexable(set,map,queue)
		Iterator<String> it = strList.iterator();
		System.out.println("type of iterator is:"+it.getClass().getName());
		while(it.hasNext()) {
			String an_element = it.next();
			System.out.println(an_element);
		}
	}
*/
	//fourth day-added
	for(String an_element: strList) {    // enhanced for-loop (for-each)
		System.out.println(an_element);
	}
	}
	
	private static void demo_specific_list() {
		List<Integer> iList = new ArrayList<Integer>();
		iList.add(123);
	//	iList.add("str");     //does not take String
		
		Integer iObj = iList.get(0);
		System.out.println(iObj);    // 123
	}

	private static void demoRawType() {
		List l = new ArrayList();
		l.add(123);
		l.add(234);
		Integer intObj = (Integer)l.get(0);
		System.out.println(intObj);
		//String s = (String)l.get(1);  //this is typecasting (conversion and typecasting are different)
		//Integer cannot be cast to class java.lang.String 
		//conversion between string and int is possible
		// in java, typecasting is allowed between two objects related by inheritance 
		//(string and int are not related by inheritance in any way)
		
		String s = (String.valueOf(l.get(1)));  //this is conversion (it is possible)
	}
	private static void demoAutoBoxing() {
		// TODO Auto-generated method stub
		ArrayList l = new ArrayList();
		l.add(0);
		l.add(1);
		l.add(100);
		l.add(2);
		l.add(3);
		l.add("abc");
		System.out.println(l);
		l.remove("abc");
		l.remove(2);   //takes 2 as index
		//to remove the value 2 from the list
		l.remove(new Integer(2));
		System.out.println(l);
		
	}
}
