import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Person from './components/Person';
import Product from './components/Product';
import axios from 'axios';
class App extends Component {
    //instance variable
  state = { //js object notation (JSON)
        personList:[{name:"Sreedhar_K",age:20},{name:"Tom",age:10},{name:"Django",age:24}],
        //productList:[{id:1,name:"Shirt",price:300,qoh:32},{id:2,name:"Denim jeans",price:1000,qoh:20},{id:3,name:"Sneakers",price:500,qoh:30}]
        productList:[]
  }

  componentDidMount(){
    axios.get("http://localhost:8080/products").then(resp => {
      this.setState({productList:resp.data});
    });
  }
    
  render() {
    return (
      /*
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Edit <code>src/App.js</code> and save to reload.
          </p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
      </div>
      */

      <div className="App">
        {/*
        {
        this.state.personList.map((aPerson) => {
          // iterating through the Person list
            return(<div><Person name={aPerson.name} age={aPerson.age} /><br/></div>)
        })
        } 
      */}
        <div className="ui cards">
        {
        this.state.productList.map((aProduct) => {
          // iterating through the Product list
          return (<Product product={aProduct} />);
        })
        }
        </div>
                
      </div>
    );
  }
}

export default App;

  /* hardcoded names
                  <Person name="Sreedhar_K" age="20"/>
                  <br></br>
                  <br></br>
                  <Person name="Tom" age="10" />    {/*  repeating the component, these 2 are the occurences of a component called Person \*/