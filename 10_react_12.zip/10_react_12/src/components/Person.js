import React, {Component} from 'react';
import './Person.css';

class Person extends Component{

    render(){
        return (
            <div>
                <h3 className="personal-detail"> My Name is {this.props.name}, I am {this.props.age} years old!!</h3>
            </div>
        );
    }

}

export default Person;