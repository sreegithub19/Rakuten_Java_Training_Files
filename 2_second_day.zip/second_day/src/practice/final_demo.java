package practice;

// we cannot inherit from a final class
public final class final_demo {
		public static void main(String[] args) {
			System.out.println("final_demo");
			final int i=10;  //final variable cannot be reassigned
			System.out.println(i);
		}
}

/*  this throws a compilation error
class impossible extends final_demo{}
we cannot override a final method using @Override
*/
