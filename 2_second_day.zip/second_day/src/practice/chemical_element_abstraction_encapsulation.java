package practice;
import java.util.*;

//import my_first_java_project.DOWFinder;

public class chemical_element_abstraction_encapsulation{
	private int atomic_number;
	private String symbol;
	private String name;
	
	//static 
	private static boolean[] alkaliMetals = new boolean[120]; //default boolean value is false
	// in order to encapsulate alkaliMetals, we use 'private'
	static {
		/*the keyword static indicates that the particular member 
		 * belongs to a type itself, rather than to an instance of that type. 
		 * This means that only one instance 
		 * of that static member is created which is shared 
		 * across all instances of the class.*/
	alkaliMetals[3]=true;
	alkaliMetals[11]=true;
	alkaliMetals[19]=true;
	alkaliMetals[37]=true;
	alkaliMetals[55]=true;
	alkaliMetals[87]=true;
	}
	//alkaliMetals[atomic_number];       //even this.atomic_number
	
	//In OOP, we do not pass parameters 
	// as these are not standalone functions  (eg:. rectangle.area()->not exactly
	//necessary to pass length and breadth
	
	//constructor (since there is a parameterized constructor,
	//compiler would not create any default constructor
	public chemical_element_abstraction_encapsulation(int atomic_number, String symbol, String name) {
		super();
		this.atomic_number = atomic_number;
		this.symbol = symbol;
		this.name = name;
	}
	
	public boolean isAlkaliMetal() {  
		// 3,11,19,37,55,87
		return alkaliMetals[atomic_number];

	}
	
	public boolean isTransitionMetal() {
		return (atomic_number>=21 && atomic_number<=31) || 
				(atomic_number>=39 && atomic_number<=48) ||
				(atomic_number>=72 && atomic_number<=80)  ||
				(atomic_number>=104 && atomic_number<=112) ;
		
	}
	
	public boolean isMetal() {
		switch(atomic_number) {
		case 13:
		case 49:
		case 50:
		case 81:
		case 82:
		case 83:
		case 113:
		case 114:
		case 115:
		case 116:
			return true;
		default:
			return false;
		
		}
	}
	
// these are getters 
	public int getAtomic_number() {
		return atomic_number;
	}

	public String getSymbol() {
		return symbol;
	}

	
	public String getName() {
		return name;
	}


	public static boolean[] getAlkaliMetals() {
		return alkaliMetals;
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		chemical_element_abstraction_encapsulation h = new chemical_element_abstraction_encapsulation(scan.nextInt(),scan.next(),scan.next());
		chemical_element_abstraction_encapsulation k = new chemical_element_abstraction_encapsulation(scan.nextInt(),scan.next(),scan.next());
		chemical_element_abstraction_encapsulation z = new chemical_element_abstraction_encapsulation(scan.nextInt(),scan.next(),scan.next());
		//here we are calling constructors.
		//hence, we need the constructor 'chemical_element' in our code
		System.out.println("is "+h.name+" an alkali? " + h.isAlkaliMetal());
		//chemical_element k = new chemical_element(11,"K","Potassium");
		System.out.println("is "+k.name+" an alkali? " + k.isAlkaliMetal());
		//chemical_element z = new chemical_element(30,"Zi","Zinc");
		System.out.println("is "+z.name+" an alkali? " + z.isAlkaliMetal());
		
		//h.atomic_number = -1  (allowing direct access will cause such issues
		//created by malicious users);
		
		//System.out.println(h.atomic_number); ->but, if any legitimate user
		//wants to do this, even he/she cannot do this if the values are private
		
		//so, we use getters and setters
		
		radioactive_element u = new radioactive_element(116,"U","Uranium",4);
		
	}
	
}
	

