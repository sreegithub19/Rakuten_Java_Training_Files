package practice;

public class inheritance_vehicle_app {
	public static void main(String args[]) {
		inheritance_driver d = new inheritance_driver();
		/*
		 * comment while 
		inheritance_vehicle v = new inheritance_vehicle();
		d.testDrive(v);
		*/
		inheritance_vehicle v = new inheritance_car();
		inheritance_car c = new inheritance_car();
		inheritance_truck t = new inheritance_truck();
		d.testDrive(t); 
		d.testDrive(c);

		//takes a vehicle as an argument, and here we gave no arguments
		// so, cannot use car as a vehicle/parameter of 'd' for now 
		//also, giving 'c'(car) as a parameter initially does not work
		//so, we do inheritance_car """extends""" inheritance_drive
		
		//so, an object of car should be able to substitute for vehicle - this is type substitution
		// here, we want an object of one type to substitute an object of another type
		//so, we can think of inheritance as a means of achieving this type substitution
		// 'extends' should be understood as 'is'
}
}
