package practice;

//inheritance is best suited for reusability of code
// extends is the keyword for inheritance in java 
public class inheritance_vehicle{
	
	
	
	
	
	//public is for the entire world to access
	//protected is only for all subclasses to access
	//private is only within that particular class to access
	//default is only for classes within the same package to access
	
	public void start_vehicle() {
		System.out.println("{{{{{{{{{{{{{{ Vehicle starting }}}}}}}}}}}}}}");
	}
	public void stop_vehicle() {
		System.out.println("{{{{{{{{{{{{{{ Vehicle stopping }}}}}}}}}}}}}}");
	}
}
