package com.rakuten.training;

import com.rakuten.training.ui.ProductConsoleUI;

public class ProductApplication {

	public static void main(String[] args) {
		
		ProductConsoleUI ui = new ProductConsoleUI();
		ui.createProductWithUI();

	}

}