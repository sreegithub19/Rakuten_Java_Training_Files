package com.rakuten.training.dal;

import java.util.List;
import com.rakuten.training.domain.Product;

public interface ProductDAO { //Data Access Object (DAO)
	public Product save(Product toBeSaved);
	public Product findById(int id);
	public List<Product> findAll();
	public void deleteById(int id);
	//this interface does not give any idea or info about 
	// how/why of the functions in it. That is the 
	//advantage of using interface.
}
