package com.rakuten.training.service;
import com.rakuten.training.domain.Product;
import com.rakuten.training.dal.ProductDAOInMemImpl;

import java.util.List;

import com.rakuten.training.dal.ProductDAO;

public class ProductServiceImpl implements ProductService {
	
	ProductDAO dao = new ProductDAOInMemImpl();
	
	@Override
	public int addProduct(Product toBeAdded) {
		if(toBeAdded.getPrice()* toBeAdded.getQoh()>=10000) {
			Product added = dao.save(toBeAdded);
			return added.getId();
		}else {
			throw new IllegalArgumentException("Product value must be >= 10000");
			//IllegalArgumentException  is a built-in java exception
		}
	}
	
	@Override
	public void removeExisting(int id) {
		Product existing = dao.findById(id);
		if(existing.getPrice()*existing.getQoh()<10000)dao.deleteById(id);
		else throw new IllegalArgumentException("Product value is >= 10000, cannot just be deleted!!");

	}
	
	@Override
	public Product findById(int id) {
		return dao.findById(id);
	}

	@Override
	public List<Product> findAll() {
		return dao.findAll();
	}
	

}
