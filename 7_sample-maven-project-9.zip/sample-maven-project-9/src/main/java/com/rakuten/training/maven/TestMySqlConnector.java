package com.rakuten.training.maven;
import com.mysql.jdbc.Driver;  // for this to get resolved,
// we added some extra xml code in the pom.xml file and saved it. 
// 2 .jars in Maven Dependencies

public class TestMySqlConnector {

	public static void main(String[] args) {
		Driver d;
		System.out.println("It works!!");
		
	}

}
