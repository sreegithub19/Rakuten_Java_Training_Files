package com.rakuten.trainings.generics;

import java.util.Comparator;
import com.rakuten.trainings.generics.chemical_element_abstraction_encapsulation;

public class chemical_element_name_length_comparator implements Comparator<chemical_element_abstraction_encapsulation>{
	
	@Override
	public int compare(chemical_element_abstraction_encapsulation o1, chemical_element_abstraction_encapsulation o2) {
		return o1.getName().length() - o2.getName().length();
		
	}

}

// 2 classes without the same access specifier in the same file
class chemical_element_name_comparator implements Comparator<chemical_element_abstraction_encapsulation>{
	
	@Override
	public int compare(chemical_element_abstraction_encapsulation o1, chemical_element_abstraction_encapsulation o2) {
		return o1.getName().compareTo(o2.getName());
		
	}

}

