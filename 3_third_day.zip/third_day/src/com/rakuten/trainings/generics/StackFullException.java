package com.rakuten.trainings.generics;

public class StackFullException extends RuntimeException {

    public StackFullException(String message, Throwable cause) {
        super(message, cause);
        
    }
}
