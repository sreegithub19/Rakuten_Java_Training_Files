package com.rakuten.trainings.generics;

public class radioactive_element extends chemical_element_abstraction_encapsulation {
	
	//Implicit super constructor 
	//chemical_element_abstraction_encapsulation() 
	//is undefined for default constructor. 
	//Must define an explicit constructor
	
	int half_life;
	public radioactive_element(int atomic_number, String symbol, String name, int half_life) {
		// TODO Auto-generated constructor stub
		     //->if you have not written anything, super() will be written here by the compiler
		 // super(0,null,null); - though it has parameters, makes no sense
		 super(atomic_number,symbol,name); //because it must call the 
		 // parent/ base class constructor -> constructor chaining
		 this.half_life = half_life;
	}
	
	public int get_half_life() {
		return half_life;
	}
	
}
