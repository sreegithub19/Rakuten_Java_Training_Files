package com.rakuten.trainings.generics;

//import com.rakuten.training.collectionschemical_element_name_length_comparator;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import com.rakuten.trainings.generics.radioactive_element;
import com.rakuten.trainings.generics.chemical_element_name_length_comparator;
//there is a java class called Number (containing int, float, double etc.)
public class Generics_demo_fourth_day {
	
	//Collections.sort() is an implementation of quick sort
	/*
	public static Object sort(List l, Comparator c) {
		return null;
	}  (modified below)
	*/
	public static <T> T  sort(List<T> l,Comparator<? super T> c) {
		
		return null;
	}
	
	public static <T> T combine(T o1,T o2) {   //this is a generic method
		//some logic for combining o1 and o2
		return null;
	}
	
	public static void printAll(List<?> l) {   // List<?> l  -> list of unknown type
		//l.add("123");  // this is raw type , so not good (without knowing the list type, we pass another type of the data)
		
	}
	
	public static double sum_the_list(List<? extends Number> nList) {
		//unknown type must be a subtype of number (when we use List<? extends Number>)  --> Wildcard
		/*
		//nList.add("abc:");    //this raw type is not a good practice;
		// but, due to backward compatibility, it is still valid
		 */
		double sum=0;
		/*
		nList.add(123); 
		//allowing addition of anything to nList
		//could be dangerous (due to unknown type(s))
		//so, this is more of a read-only data
		 */
		for(Number n:nList) {sum+=n.doubleValue();}
		return sum;
	}

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = combine("Hello","World!!");  //typecasting here 
		//String x = combine("Hello",10);   // it shows error for different types
											//passed as arguments
		Integer sum = (Integer) combine(10,32);
		
		
		Object o = new Integer(42);
		List l = new ArrayList();
		
	//	List<Object> l1 = new ArrayList<Integer>();
		
		//in the above line, the inheritance relation between <Object> (base)
		//and <Integer> (child) does not matter here;
		//both the types have to be the same
		List<Float> f_list = new ArrayList<>();
		sum_the_list(f_list);
		ArrayList<Integer> i_list = new ArrayList<Integer>();
		//List<Object> o_list = i_list;
		i_list.add(123);
		
//		sort(i_list,new chemical_element_name_length_comparator());
		List<radioactive_element> reList = new ArrayList<>();
		sort(reList,new chemical_element_name_length_comparator());
		//i_list.add("123");  // does not work
	//	double sum = sum_the_list(i_list); //does not work 
		// the inheritance relation between <Number> (base)
		//and <Integer> (child) does not matter here;
		//both the types have to be the same
		
		/*
		List<Object> o_list = i_list;
		o_list.add("abc");
		int val = i_list.get(1);
		*/

	}

}
