package com.rakuten.trainings.generics;

//this file is the stack interface (that should be generalized here)
//abstract classes and interfaces

/*contents*/
// interface Stack (LIFO)
	// methods of stack:
		//1. public void push(Object element)
		//2. public Object pop()

// implementation class of Stack - FixedArrayStack
public interface Stack<E> {    // same name as file
	public void push(E element);
	// object is reference type and element(int) is primititve type
	public E pop();
}


