package com.rakuten.trainings.generics;

public class StackApp {
	public static void main(String[] args) {
		FixedArrayStack<Integer> st = new FixedArrayStack<>(10);  
		//<>  -> diamond operator (assumed type from the statement)
		//DynaStack dt = new DynaStack(10);
		
		StackUser u = new StackUser();
		//u.fill(dt);
		u.fill(st);
	}
}
