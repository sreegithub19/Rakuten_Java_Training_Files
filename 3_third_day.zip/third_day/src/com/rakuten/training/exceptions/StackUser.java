package com.rakuten.training.exceptions;

/*
// Loose coupling (programming to the interface) - when one object interacting with another object (StackUser and FixedArrayStack) using a reference of an interface type (Stack s)
// the invoking object has no knowledge of the concrete type of the object receiving the implementation call
//StackUser is loosely(indirectly) coupled with FixedArrayStack
// but, StackUser is tightly(directly) coupled with 
// the idea/interface of Stack
 * 
 * 
 * refer to SOLID principles
 */
public class StackUser {
	//StackUser relies on the contract/idea/interface of Stack
	// this is the consumer of the contract
	public void fill (Stack s) {
		for(int i=0;i<10;i++) {
			s.push(i);  //what the compiler would be doing -> s.push(new Integer(i));
			//this is 'autoboxing'
			//eg: Integer iobj = 10;  ->(converted by compiler to)->  new Integer(10);
			// we would have done the below line prior to Java 5
			//s.push(new Integer(i));  -> constructor Integer is deprecated since Java9
			//public void push(Object element);
			//would have shown error between object and int are incompatible
			//but, since java5, concept of 'autoboxing' has been introduced
			//wrapper classes in java act as wrapper around primitives
			System.out.println("Pushed--->"+i);
		}
			
	}
}
