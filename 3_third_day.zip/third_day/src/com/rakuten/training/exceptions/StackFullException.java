package com.rakuten.training.exceptions;

public class StackFullException extends RuntimeException {

    public StackFullException(String message, Throwable cause) {
        super(message, cause);
        
    }
}
