package com.rakuten.training.basics;

public class StackApp {
	public static void main(String[] args) {
		//FixedArrayStack st = new FixedArrayStack(10);
		DynaStack dt = new DynaStack(10);
		
		StackUser u = new StackUser();
		u.fill(dt);
		//u.fill(st);
	}
}
