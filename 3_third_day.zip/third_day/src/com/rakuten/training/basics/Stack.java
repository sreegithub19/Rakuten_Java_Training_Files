package com.rakuten.training.basics;

//abstract classes and interfaces

/*contents*/
// interface Stack (LIFO)
	// methods of stack:
		//1. public void push(Object element)
		//2. public Object pop()

// implementation class of Stack - FixedArrayStack
public interface Stack {    // same name as file
	public void push(Object element);
	// object is reference type and element(int) is primititve type
	public Object pop();
}


