package com.rakuten.training.basics;

//FixedArrayStack is a concrete implementation of interface/idea Stack
// FixedArrayStack is the fulfiller of the contract
public class FixedArrayStack implements Stack{  
	//we get to override  the 'Stack' interface methods in FixedArrayStack
	private Object[] contents;
	private int top = -1;
	
	public FixedArrayStack(int capacity) {
		contents = new Object[capacity];
	  }
	
	@Override
	public void push(Object element) {
		contents[++top]= element;
	}
	
	@Override
	public Object pop() {
		return contents[top--];
		//extract top contents and then decrement top
	}
}