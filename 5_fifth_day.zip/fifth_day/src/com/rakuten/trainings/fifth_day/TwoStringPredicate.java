package com.rakuten.trainings.fifth_day;

//this should be a functional interface (a target for lambda functions)
@FunctionalInterface
public interface TwoStringPredicate {
	boolean is_first_better_than_second( String first, String second);
	
	public default void a_default_method() {
		System.out.println("Default!!");
	}
}
