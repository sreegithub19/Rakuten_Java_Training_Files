package com.rakuten.trainings.streams;

import java.util.Optional;

import com.rakuten.training.collections.chemical_element_abstraction_encapsulation;

public class Test {
	public static final chemical_element_abstraction_encapsulation first = new chemical_element_abstraction_encapsulation(1,"h","hydrogen");
	public static Optional<chemical_element_abstraction_encapsulation> readFromDB(int atomic_number) {
		// connect to db
		// search based on atomic number
		//if found
		boolean found = false;
		if(found) {
			chemical_element_abstraction_encapsulation e = new chemical_element_abstraction_encapsulation(0,null,null);
			//return e;
			return Optional.of(e);  //to avoid the rude output (see the TestOfTest.java file)
		}
		else {
			System.out.println("Not found!!");
			return Optional.empty();
		}
		//return null;
	}
}
