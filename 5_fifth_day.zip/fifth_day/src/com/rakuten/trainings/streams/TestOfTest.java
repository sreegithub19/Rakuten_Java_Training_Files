package com.rakuten.trainings.streams;

import java.util.Optional;

import com.rakuten.training.collections.chemical_element_abstraction_encapsulation;

public class TestOfTest {
	public static void main(String[] args) {
		Test.first.isAlkaliMetal();
		System.out.println("ADDD"); //System.out::println
		
		Optional<chemical_element_abstraction_encapsulation> opt = Test.readFromDB(115);
		// the above line is promising to return a chemical element, but actually prints null_pointer_exception
		chemical_element_abstraction_encapsulation c = opt.orElse(new chemical_element_abstraction_encapsulation(1,"h","hydrogen"));
		if(opt.isPresent()) {
		chemical_element_abstraction_encapsulation e = opt.get();
		if(e.getSymbol().equalsIgnoreCase("Unu")) {
			System.out.println("This is unobtainium....");
		}
		
	}
	}
}
