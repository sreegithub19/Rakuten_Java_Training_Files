package com.rakuten.training.collections;
import java.util.Arrays;
// any interface with only one abstract method is called a functional interface

/*  Exercise - 
1. Basic lambdas. Make an array containing a few Strings. Sort it by
• length (i.e., shortest to longest)
• reverse length (i.e., longest to shortest)
• alphabetically by the first character only
• Strings that contain “e” first, everything else second
Note 1: the compare method of Comparator should return a negative number if the first entry is
“less” than the second, a positive number if the first entry is “greater” than the second, and 0 if they
are the same. See the JavaDoc API for details.
Note 2: to print out an array after sorting, do System.out.println(Arrays.asList(yourArray))
The point of this is that if you just print an array directly, you do not see anything useful (just the
memory address), but if you print a List, it shows the individual elements separated by commas.
So, the above trick is simpler than making a loop to traverse the array and print out the elements.
*/

public class lambda_expressions {
	public static void main(String[] args) {
		Arrays.sort(sort_demo.strings,
				(s1,s2)->s1.length()-s2.length());
		System.out.println(Arrays.asList(sort_demo.strings));
		Arrays.sort(sort_demo.strings,
				(s1,s2)->s2.length()-s1.length());
		System.out.println(Arrays.asList(sort_demo.strings));
		Arrays.sort(sort_demo.strings,
				(s1,s2)->s1.substring(0,1).compareTo(s2.substring(0,1)));
		System.out.println(Arrays.asList(sort_demo.strings));
		Arrays.sort(sort_demo.strings,
				(s1,s2)-> {
					if(s1.contains("e") && !s2.contains("e")) {
						return -1;
					}else if(!s1.contains("e") && s2.contains("e")) {
						return 1;
					}else {
						return 0;
					}
				});
		System.out.println(Arrays.asList(sort_demo.strings));
	}

}
