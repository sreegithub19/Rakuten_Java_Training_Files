package com.rakuten.training.collections;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

import com.rakuten.training.collections.chemical_element_abstraction_encapsulation;

public class sort_demo {
	public static String[] strings = {"this","is","a","bunch","of","strange","words","like","camel","and","cieling"};
	
	public static void main(String[] args) {
		//simple_string_array_sort();
		//simple_string_list_sort();
		//sort_user_defined_type_list();
		sort_user_defined_type_list_using_comparator();
	}
	
	/***************************************************************************/
	public static void sort_user_defined_type_list() {
		chemical_element_abstraction_encapsulation h = new chemical_element_abstraction_encapsulation(1,"H","hydrogen");
		chemical_element_abstraction_encapsulation k = new chemical_element_abstraction_encapsulation(1,"K","potassium");
		chemical_element_abstraction_encapsulation o = new chemical_element_abstraction_encapsulation(1,"O","oxygen");
	
			List<chemical_element_abstraction_encapsulation> c_list = new ArrayList<>();
			c_list.add(o);
			c_list.add(h);
			c_list.add(k);
			System.out.println("before sorting:\n"+c_list);
			Collections.sort(c_list);  //-->
			System.out.println("before sorting:\n"+c_list);
			//The method sort(List<T>) in the type Collections 
			//is not applicable for the arguments (List<chemical_element_abstraction_encapsulation>)
			//because c_list is user-defined (not built in type).
			//the type must implement the interface 'comparable' (whether it is built-in or user-defined)
			
			
	}
	
	/*********************************************************************/
	public static void sort_user_defined_type_list_using_comparator() {
		//sorting of user-defined type is done based on a specific parameter (here at_number)
		//suppose we want to sort based on some other parameter (say, symbol, or element_name)
		chemical_element_abstraction_encapsulation h = new chemical_element_abstraction_encapsulation(1,"H","hydrogen");
		chemical_element_abstraction_encapsulation k = new chemical_element_abstraction_encapsulation(19,"K","potassium");
		chemical_element_abstraction_encapsulation o = new chemical_element_abstraction_encapsulation(8,"O","oxygen");
	
			List<chemical_element_abstraction_encapsulation> c_list = new ArrayList<>();
			c_list.add(o);
			c_list.add(h);
			c_list.add(k);
			System.out.println("before sorting:\n"+c_list);  // added in the order -> o,h,k
			Collections.sort(c_list);  //-->
			System.out.println("after sorting:\n"+c_list);  // after sorting -> h,o,k
			
		//	chemical_element_name_length_comparator comparisonLogic = new chemical_element_name_length_comparator();
			chemical_element_name_comparator comparisonLogic = new chemical_element_name_comparator();
			System.out.println("before sort:\n"+c_list);
			Collections.sort(c_list,comparisonLogic);
			
			//anonymous inner class---/////////////////////
			Collections.sort(c_list,new Comparator<chemical_element_abstraction_encapsulation>(){
				@Override	
					public int compare(chemical_element_abstraction_encapsulation o1, chemical_element_abstraction_encapsulation o2)
					{
						return o1.getName().compareTo(o2.getName());
					}
			});
			////////////////////////
			System.out.println("after sort:\n"+c_list);
			}
	
	
	/**********************************************************************/
	public static void simple_string_list_sort() {
		List<String> s_list = Arrays.asList(strings);
		System.out.println("before sorting:\n"+s_list);
		Collections.sort(s_list);   //equals() and hashcode() are for checking equality,
									// not for any comparison
		// to enable comparison for user-defined data types,
		//use comparable ( in chemical_element_abstraction_encapsulation.java ) - 
		// public class chemical_element_abstraction_encapsulation implements Comparable<chemical_element_abstraction_encapsulation>
		System.out.println("after sorting:\n"+s_list);
		//java cannot compare two objects of user-defined class
	}
	
	/**********************************************************************/
	public static void simple_string_array_sort() {
		//System.out.println("Before sort\n"+strings);
		System.out.println("Before sort\n"+Arrays.asList(strings));
		chemical_element_abstraction_encapsulation h = new chemical_element_abstraction_encapsulation(1,"H","hydrogen");
		System.out.println(h);  //toString() by default (by JVM) returns string followed by memory address.
		// in order to make it print the string as is, we override toString() (or) Source->generate String. 
		String q = "Hello " + h;
		System.out.println((q));
		Arrays.sort(strings);
		System.out.println("After sort\n"+Arrays.asList(strings));
	}
}

