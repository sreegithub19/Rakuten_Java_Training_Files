package com.rakuten.training.collections;

/*
 * map methods used here:
 	* put
 	* containsKey
 	* get
 	* containsValue
 */
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import com.rakuten.training.collections.chemical_element_abstraction_encapsulation;
//hash map is the most widely used implementation of the map collection
//reverse lookup is not possible (getting key from value is not possible)
//treeset is an implementation of a sorted map
public class map_demo {
	public static void main(String[] args) {
		//simple_map_ops();
		user_defined_map();
	}
	
	public static void user_defined_map() {
		Map<chemical_element_abstraction_encapsulation,Double> earth_composition = new HashMap<>();
		chemical_element_abstraction_encapsulation h = new chemical_element_abstraction_encapsulation(1,"H","hydrogen");
		chemical_element_abstraction_encapsulation k = new chemical_element_abstraction_encapsulation(19,"K","potassium");
		chemical_element_abstraction_encapsulation o = new chemical_element_abstraction_encapsulation(8,"O","oxygen");
		
		earth_composition.put(h,15.3);
		earth_composition.put(o,40d);
		earth_composition.put(k,3.4);
		
		Scanner kb = new Scanner(System.in);
		System.out.println("Enter an atomic number:");
		int at_number = Integer.parseInt(kb.nextLine());
		chemical_element_abstraction_encapsulation unknown = new chemical_element_abstraction_encapsulation(at_number,null,null);
		
		if(earth_composition.containsKey(unknown)) {
			double percentage = earth_composition.get(unknown);
			System.out.println("Element with atomic number "+at_number+" is "+percentage+"% of earth.");
		}
		else {
			System.out.println("No data for element with that atomic number.");
		}
	}
	
	
	private static void simple_map_ops() {
		/*Map<String,Integer> runs = new HashMap<>(); */   //iteration order != insertion order
		Map<String,Integer> runs = new LinkedHashMap<>();   //iteration order == insertion order
		runs.put("Virat",99);  //put is for adding values into map
		runs.put("Rohit",36);
		runs.put("ASHWIN",100);
		String s;
		System.out.println("Do we have runs of Virat?"+runs.containsKey("Virat"));  //true 
		System.out.println("Do we have runs of Jinx?"+runs.containsKey("Jinx"));  //false
		System.out.println("Runs scored by Virat:"+runs.get("Virat"));   //99
		System.out.println("Has anyone scored perfect 100?"+runs.containsValue(100)+" by "+runs.keySet());   //true by [Rohit, ASHWIN, Virat]
		
		Set<String> keys = runs.keySet();
		for(String a_key : keys) {
			if(runs.get(a_key)== 100) {System.out.println(a_key);}
			System.out.println(a_key+"---->"+runs.get(a_key));  
			//iteration order is random (not same as insertion order)
			//due to the internal hashing that takes place, iteration order is not 
			//the same as insertion order in hashmap
			
		}
	}
}
