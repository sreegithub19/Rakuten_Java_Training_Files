package com.rakuten.training.collections;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
//TreeSet<> is an implementation of SortedSet
//set  -> hashset
public class set_demo {
	public static void main(String[] args) {
		//Set<String> uniqueWords = new HashSet<>(); //iteration order!= insertion order
	//	Set<String> uniqueWords = new LinkedHashSet<>(); //iteration order== insertion order
		Set<String> uniqueWords = new TreeSet<>(); 
		Scanner kb = new Scanner(System.in);
		while(true) {
			System.out.println("Enter a word (or quit):");
			String a_word = kb.nextLine();
			if(a_word.equalsIgnoreCase("quit")) break;
			//equalsIgnoreCase is for case-insensitive string comparison
			if(!uniqueWords.add(a_word)) {System.out.println("Duplicate detected!!");}
		}
		System.out.println("_____________ALL WORDS_________________");
		for (String s: uniqueWords) System.out.println(s);
	}
}
